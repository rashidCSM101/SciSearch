import json
import re
from pathlib import Path
from typing import Dict, List

def build_index(data_dir: str, index_path: str, metadata_path: str):
    """
    Build inverted index and metadata for documents in data_dir.
    
    Args:
        data_dir: Directory containing document files (e.g., .txt)
        index_path: Path to save inverted_index.json
        metadata_path: Path to save document_metadata.json
    """
    data_dir = Path(data_dir)
    index_dir = Path(index_path).parent
    index_dir.mkdir(exist_ok=True)
    
    inverted_index = {
        'any': {},
        'title': {},
        'author': {},
        'abstract': {}
    }
    metadata = {}
    
    # Process each document
    for doc_id, doc_path in enumerate(data_dir.glob("*.txt")):
        try:
            with open(doc_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Simulate metadata extraction (adjust based on actual document format)
            title = f"Document Title {doc_id + 1}"
            author = "Unknown Author"
            abstract = content[:200] if len(content) > 200 else content
            tokens = re.findall(r'\w+', content.lower())
            
            # Store metadata
            metadata[doc_id] = {
                'title': title,
                'author': author,
                'abstract': abstract,
                'file_path': str(doc_path)
            }
            
            # Build inverted index for 'any' field
            for pos, term in enumerate(tokens):
                if term not in inverted_index['any']:
                    inverted_index['any'][term] = {}
                if str(doc_id) not in inverted_index['any'][term]:
                    inverted_index['any'][term][str(doc_id)] = []
                inverted_index['any'][term][str(doc_id)].append(pos)
            
            # Index title
            title_tokens = re.findall(r'\w+', title.lower())
            for pos, term in enumerate(title_tokens):
                if term not in inverted_index['title']:
                    inverted_index['title'][term] = {}
                if str(doc_id) not in inverted_index['title'][term]:
                    inverted_index['title'][term][str(doc_id)] = []
                inverted_index['title'][term][str(doc_id)].append(pos)
            
            # Index author
            author_tokens = re.findall(r'\w+', author.lower())
            for pos, term in enumerate(author_tokens):
                if term not in inverted_index['author']:
                    inverted_index['author'][term] = {}
                if str(doc_id) not in inverted_index['author'][term]:
                    inverted_index['author'][term][str(doc_id)] = []
                inverted_index['author'][term][str(doc_id)].append(pos)
            
            # Index abstract
            abstract_tokens = re.findall(r'\w+', abstract.lower())
            for pos, term in enumerate(abstract_tokens):
                if term not in inverted_index['abstract']:
                    inverted_index['abstract'][term] = {}
                if str(doc_id) not in inverted_index['abstract'][term]:
                    inverted_index['abstract'][term][str(doc_id)] = []
                inverted_index['abstract'][term][str(doc_id)].append(pos)
        
        except Exception as e:
            print(f"Error processing {doc_path}: {e}")
            continue
    
    # Save inverted index and metadata
    try:
        with open(index_path, 'w', encoding='utf-8') as f:
            json.dump(inverted_index, f, indent=2)
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, indent=2)
        print(f"Index built successfully: {len(metadata)} documents indexed")
    except Exception as e:
        print(f"Error saving index files: {e}")

if __name__ == "__main__":
    from pathlib import Path
    BASE_DIR = Path(__file__).parent
    DATA_DIR = Path(r"D:\Mphil CS\IRS\Assignment\TXT 1-250")  # Path to folder with text files
    INDEX_PATH = BASE_DIR / "index_files" / "inverted_index.json"  # Save inverted_index.json in project_folder/index_files
    METADATA_PATH = BASE_DIR / "index_files" / "document_metadata.json"  # Save document_metadata.json in project_folder/index_files
    
    build_index(DATA_DIR, INDEX_PATH, METADATA_PATH)